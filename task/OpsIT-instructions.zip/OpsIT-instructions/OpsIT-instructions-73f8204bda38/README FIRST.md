Before you proceed make sure to rename the following files:
1. gradlew.batt -> gradlew.bat
2. gradle/wrapper/gradle-wrapper.jarr -> gradle/wrapper/gradle-wrapper.jar

Good luck!
